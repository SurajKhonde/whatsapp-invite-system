ALTER TABLE "templates" ADD COLUMN "type" varchar(20) DEFAULT 'text' NOT NULL;--> statement-breakpoint
ALTER TABLE "templates" ADD COLUMN "preview_image_url_full" varchar(500);