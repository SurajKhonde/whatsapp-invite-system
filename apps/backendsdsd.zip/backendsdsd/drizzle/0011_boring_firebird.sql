ALTER TABLE "templates" ADD COLUMN "processing_status" varchar(50) DEFAULT 'queued';--> statement-breakpoint
ALTER TABLE "templates" ADD COLUMN "processing_step" varchar(100);--> statement-breakpoint
ALTER TABLE "templates" ADD COLUMN "processing_error" text;